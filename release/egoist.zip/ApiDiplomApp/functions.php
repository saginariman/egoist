<?php
header("Access-Control-Allow-Origin: *");
require_once 'connect.php';
$postData = file_get_contents('php://input');
$data = json_decode($postData, true);
$res = ['mess'=>'Ни один из запроссов не обработан!', 'status'=>false];
function resultToArray($result){
    $array = array();
    while (($row = $result->fetch_assoc()) != false) {
        $array[] = $row;
    }
    return $array;
}

if($data['getDataCats']){
    global $mysqli;
    connectDB();
    $result=$mysqli->query("SELECT * FROM `diplom_app_cats` ORDER BY `id`");
    closeDB();
    $arr_cats = resultToArray($result);
    if(count($arr_cats)){
        $res['mess'] = 'Успешно загрузка категорий!';
        $res['status'] = true;
        $res['data'] = $arr_cats;
    }else{
        $res['mess'] = 'Провал загрузки категорий - '.$mysqli->error;
        $res['status'] = false;
    }
    echo json_encode($res);
}
if($data['getNews']){
    global $mysqli;
    connectDB();
    $result=$mysqli->query("SELECT * FROM `diplom_app_news` ORDER BY `id`DESC ");
    closeDB();
    $arr_news = resultToArray($result);
    if(count($arr_news)){
        $res['mess'] = 'Успешно загрузка новостей!';
        $res['status'] = true;
        $res['data'] = $arr_news;
    }else{
        $res['mess'] = 'Провал загрузки новостей - '.$mysqli->error;
        $res['status'] = false;
    }
    echo json_encode($res);
}
?>